// FILE INI TIDAK DI-COMMIT (ada di .gitignore).
// Tiap anggota tim membuat sendiri file ini di laptopnya.
const String apiKey = 'ISI_API_KEY_KAMU';
